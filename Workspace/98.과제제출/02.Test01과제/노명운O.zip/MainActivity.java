package com.example.test01layout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    ImageView img_ex1, img_ex2, img_ex3;
    ImageView img_view1, img_view2, img_view3;
    Button btn1, btn2;
    int index = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        img_ex1 = findViewById(R.id.img_ex1);
        img_ex2 = findViewById(R.id.img_ex2);
        img_ex3 = findViewById(R.id.img_ex3);
        img_view1 = findViewById(R.id.img_view1);
        img_view2 = findViewById(R.id.img_view2);
        img_view3 = findViewById(R.id.img_view3);
        btn1 = findViewById(R.id.btn_change);
        btn2 = findViewById(R.id.btn_change_view);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (index == 3) {
                    index = 1;
                    change();
                }else {
                    index++;
                    change();
                }
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                change_view();
            }
        });

    }

    public void change() {
        img_ex1.setVisibility(View.GONE);
        img_ex2.setVisibility(View.GONE);
        img_ex3.setVisibility(View.GONE);
        if (index == 1) {
            img_ex1.setVisibility(View.VISIBLE);
        } else if (index == 2) {
            img_ex2.setVisibility(View.VISIBLE);
        } else if (index == 3) {
            img_ex3.setVisibility(View.VISIBLE);
        }

    }
    public  void change_view(){
        img_view1.setVisibility(View.GONE);
        img_view2.setVisibility(View.GONE);
        img_view3.setVisibility(View.GONE);
        if (index == 1) {
            img_view1.setVisibility(View.VISIBLE);
        } else if (index == 2) {
            img_view2.setVisibility(View.VISIBLE);
        } else if (index == 3) {
            img_view3.setVisibility(View.VISIBLE);
        }
    }
}